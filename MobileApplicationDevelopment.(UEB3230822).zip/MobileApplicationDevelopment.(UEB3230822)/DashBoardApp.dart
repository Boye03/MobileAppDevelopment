import 'package:flutter/material.dart';

void main() => runApp(courseDashboardApp());

class courseDashboardApp extends StatelessWidget {
    @override
    Widget build(BuildContext context) {
        return MaterialApp(
            title: 'course Dashboard',
            theme: ThemeData(primarySwatch: colors.blue),
            home: DashboardHome(),
        );
    }
}

class DashboardHome extends StatefulWidget {
    @override
    _DashboardHomeState createState() => _DashboardHomeState();
}

class _DashboardHomeState extends State<DashboardHome> {
    int _selectedIndex = 0;
    String _selectCategory = 'None';
    double _buttonScale = 1.0;

    final List<Map<String, String>> courses =[
        {'name': 'Literature', 'instructor': 'prof. Willam', 'icon': 'book'},
        {'name': 'Physics', 'instructor': 'Dr. Maxwell', 'icon': 'Science'},
        {'name': 'Programming', 'instructor': 'prof. Emmanuel', 'icon': 'code'},
        {'name': 'Mathematics', 'instructor': 'Dr. Pascal', 'icon': 'calculate'},
    ];

    static const List<String>categories = ['Science','Mathematics','Tecnology'];

    void _onTabTapped(int index) {
        setState(() => _selectedIndex = index);
    }

    void _showExitDialog() {
        showDialog(
            context: context,
            builder: (_) => AlertDialog(
                title: Text('Exit Confirmation'),
                content: Text('Are you sure you want to exit this app?'),
                actions: [
                    TextButton(onPressed: () => Navigator.pop(context), child: Text('No')),
                    TextButton(onPressed: () => Navigator.pop(context), child: Text('yes')),
                ],
            ),
        );
    }

    Widget _buildCourseList() {
        return ListView.builder(
            itemCount: courses.length,
            itemBuilder: (_, index) {
                var course = courses[index];
                return ListTile(
                    leading: Icon(_getIcon(course['icon']!)),
                    title: Text(course['name']!),
                    subtitle: Text('Instructor: ${course['instructor']}'),
                );
            },
        );
    }

    IconData _getIcon(String name) {
        switch (name) {
            case 'science': return Icons.science;
            case 'book': return Icons.book;
            case 'code': return Icons.code;
            case 'calculate': return Icons. calculate;
            default: return Icons.school;
        }
    }

    Widget _buildBody() {
        switch (_selectedIndex) {
            case 0:
            return Center(child:Text('Home Tab', style: TextStyle(fontSize:24)));
            case 1:
            return Column(
                children: [
                    Expanded(child: _buildCourseList()),
                    DropdownButton<String>(
                        value: _selectCategory == 'None' ? null : _selectCategory,
                        hint: Text('Select Category'),
                        items: categories.map((cat) => DropdownMenuItem(value: cat, child: Text(cat))).toList(),
                        onChanged: (val) =>setState(() => _selectCategory = val!),
                    ),
                    if (_selectCategory != 'None')
                    padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text('Selected Category: $_selectCategory'),
                    ),
                    GestureDetector(
                        onTap:() {
                            setState(() => _buttonScale = _buttonScale == 1.0 ? 1.5 : 1.0);

                        },
                        child: AnimatedScale(
                            scale: _buttonScale,
                            duration: Duration(miliseconds:300),
                            child: ElevatedButon(
                                onPressed: () {},
                                child: Text('Enroll in a Course'),
                            ),
                        ),
                    ),
                ],
            );

            case 2:
            return Column(
                mainAxisAlignment: mainAxisAlignment.center,
                children: [
                    Text('Profile Tab', style: TextStyle(fontSize: 24)),
                    ElevatedButon(onPressed:_showExitDialog, child: Text('Logout')),
                ],
            );
            default:
            return Container();
            
        }
    }

    @verride
    Widget build(BuildContext context) {
        return scaffold(
            appBar: appBar(title: Text('Course Dashboard')),
            body: _buildBody(),
            bottomNavigationBar: BottomNavigationBar(
                currentIndex: _selectedIndex,
                onTap: _onTabTapped,
                items: [
                    BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
                    BottomNavigationBarItem(icon: Icon(Icons.list), label: 'Courses'),
                    BottomNavigationBarItem(icon: Icon(Icons.person), label: 'profile'),                    
                ],
            ),
        );
    }
}