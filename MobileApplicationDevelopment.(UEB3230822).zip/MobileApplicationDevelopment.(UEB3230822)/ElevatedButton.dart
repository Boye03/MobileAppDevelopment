void showWelcomeSnackBar(BuildContext content) {
    scaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Hello, ENESIMUS! Welcome to the student info Manager."))
    );
 }

ElevatedButton(
    onPressed: () => showWelcomeSnackBar(context),
child: Text("Show Alert"),
)
