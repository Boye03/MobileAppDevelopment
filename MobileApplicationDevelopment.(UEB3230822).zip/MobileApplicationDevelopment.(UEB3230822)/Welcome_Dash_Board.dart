import 'package:flutter/material.dart';

class WelcomeDashBoard extends StatelessWidget {
    return scaffold(
        body: center(
            child: padding(
                padding: EdgeInsets.all(20),
                child: Column(
                    mainAxisAlignment: mainAxisAlignment.center,
                    children: [
                        Text("ENESIMUS", style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
                        Text("course: Mobile App Development",textAlign: TextAlign.center),
                        Text("University: [University Of Energy And Natural Resources]", textAlign: TextAlign.center),
                    ],
                ),
            ),
        ),
    ),
}