final _formKey = GlobalKey<FormState>();
string email = '', password = '';

form(
    key: _formKey,
    child: Column(
        children: [
            TextFormField(
                decoration: InputDecoration(labelText: 'Email'),
                validator: (value) => value != null && value.contains('@') ? null : 'Enter a valid email',
                onChanged: (value) => email = value,
            ),
            TextFormField(
                decoration: InputDecoration(labelText: 'Password'),
                obscureText: true,
                validator: (value) => value != null && value.length >= 6 ? null:'Password must be 6+ chars',
                onChanged: (value) => password = value,
            ),
            ElevatedButton(
                onPressed: () {
                    if (_formKey.currentState! .validate()) {
                        // Proceed With login
                    }
                },
                child: Text("Login"),
            ),
        ],
    ),
)