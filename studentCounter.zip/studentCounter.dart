int studentCount = 0;

Widget buildcounter() {
    return Row(
        mainAxisAlignment: mainAxisAlignment.center,
        children: [
            IconButton(icon: Icon(Icons.remove), onPressed:() => setState(() => studentCount--)),
            Text('$studentCount', style: TextStyle(fontSize: 32)),
            IconButton(icon: Icon(Icons.add), onPressed: () => setState(() => studentCount++)),
        ],
    );
}
