Widget buildProfilePicture() {
  return Center(
    child: Image.network(
      'https://example.com/profile.jpg',
      width: 150,
      height: 150,
      fit: BoxFit.cover,
    ),
  );
}